﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace DynLan.OnpEngine.Models
{
    public class ExpressionValue
    {
        public Object Value;

        ////////////////////////////////////

        public ExpressionValue(Object Value)
        {
            this.Value = Value;
        }
    }
}