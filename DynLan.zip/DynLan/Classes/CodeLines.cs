﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DynLan.Classes
{
    public class CodeLines : List<CodeLine>
    {
        public CodeLines()
        {

        }
    }
}
